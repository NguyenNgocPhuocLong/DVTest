export interface VersionDetect {
  nameArg?: string;
}

export type VersionDetectFileType = {
  version: string;
};
