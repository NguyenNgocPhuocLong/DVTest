export const VERSION_APP = "";
export const VERSION_STORAGE_KEY = "VersionApp";
export const MAX_RETRY_TIMES = 3;
export const RETRY_RELOAD_KEY = "RETRY_RELOAD";
