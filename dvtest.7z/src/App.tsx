import "./App.css";
import VersionDetect from "./features/VersionDetect";

function App() {
  return (
    <>
      <VersionDetect></VersionDetect>
    </>
  );
}

export default App;

